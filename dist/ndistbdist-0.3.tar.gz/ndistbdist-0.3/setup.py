from setuptools import setup

setup(name='ndistbdist',
      version='0.3',
      description='Gaussian and Binomial distributions',
      packages=['ndistbdist'],
      author=['Garvit Kataria'],
      zip_safe=False)
